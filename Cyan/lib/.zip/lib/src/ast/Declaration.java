package ast;

/** represents a declaration which may be a prototype declaration, a method, or a field.
 *
   @author Jos�

 */
public interface Declaration extends ASTNode {



}







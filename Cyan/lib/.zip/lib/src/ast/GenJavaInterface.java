/**
 *
 */
package ast;

import saci.Env;

/**
 * @author Jos�
 *
 */
public interface GenJavaInterface {
	void genJava(PWInterface pw, Env env);

}
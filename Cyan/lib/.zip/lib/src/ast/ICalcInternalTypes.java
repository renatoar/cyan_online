package ast;

import meta.WrEnv;

public interface ICalcInternalTypes {

	void calcInternalTypes(WrEnv env);

}

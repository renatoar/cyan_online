package ast;

/**
 * exception thrown when Cyan statements being interpreted
 * execute a return statement
   @author jose
 */
public class ReturnValueEvalEnvException extends RuntimeException {

	/**

	 */
	private static final long serialVersionUID = 1511188758756390160L;

}

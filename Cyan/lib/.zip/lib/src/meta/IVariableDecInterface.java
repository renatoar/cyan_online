package meta;

public interface IVariableDecInterface {
	WrType getType();
	String getName();
}

package meta;

public class ParameterComplexName {
	public String name;
	public String type;
}

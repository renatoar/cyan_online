package meta;

public interface IICalcInternalTypes {
	void calcInternalTypes(WrEnv env);
}

package meta;

abstract public class WrSlotDec extends WrASTNode {

}

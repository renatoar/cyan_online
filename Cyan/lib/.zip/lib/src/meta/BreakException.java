package meta;


/**
 * exceptin thrown when the Cyan interpreter finds a 'break' statement
   @author jose
 */
public class BreakException extends RuntimeException {

	private static final long serialVersionUID = -5107615589030843741L;

}

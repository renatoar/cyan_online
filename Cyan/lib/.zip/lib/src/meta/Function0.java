package meta;

@FunctionalInterface
public interface  Function0 {
    void eval();
}
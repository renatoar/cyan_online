package meta;

public interface ICheckPrototype_bsa {
	
	void bsa_checkPrototype(ICompiler_semAn compiler);
	
}

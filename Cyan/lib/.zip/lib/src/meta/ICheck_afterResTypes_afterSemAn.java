package meta;

/**
 * super-interface of all interfaces that do checking in the Cyan source code
   @author jose
 */
public interface ICheck_afterResTypes_afterSemAn {

}

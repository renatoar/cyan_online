package meta;

public interface IListAfter_afterResTypes {
	void after_afterResTypes_action(ICompiler_afterResTypes compiler);
	WrCompilationUnit getCompilationUnit();
}

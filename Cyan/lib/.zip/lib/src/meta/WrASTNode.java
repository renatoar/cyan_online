package meta;

import ast.ASTNode;

public abstract class WrASTNode {

	abstract ASTNode getHidden();

}

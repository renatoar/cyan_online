package meta;

public interface ICompiler_dpp extends IAbstractCyanCompiler {

}

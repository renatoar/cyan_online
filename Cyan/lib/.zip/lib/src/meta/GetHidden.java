package meta;

public interface GetHidden<T> {
	T getHidden();
}

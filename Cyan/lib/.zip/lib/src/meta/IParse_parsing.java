package meta;

/**
 * super interface of all interfaces for parsing during phase parsing (During PArsing).
   @author jose
 */

public interface IParse_parsing  {

	
}

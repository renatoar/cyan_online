package meta;

/**
 * This enumerate will be deprecated. It is only used in metaobject 'concept'.
 * Do not use it.
   @author jose
 */
public enum ParsingPhase {
	dpaGeneric, dpaNonGeneric
}

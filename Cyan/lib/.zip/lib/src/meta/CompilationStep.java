/**

 */
package meta;

/** The compilation step
   @author Jos�

 */
public enum CompilationStep {
	step_1, step_2, step_3, step_4, step_5, step_6, step_7, step_8, step_9, step_10
}

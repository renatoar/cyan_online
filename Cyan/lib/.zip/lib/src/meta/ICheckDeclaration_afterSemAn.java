package meta;

public interface ICheckDeclaration_afterSemAn extends ICheck_afterResTypes_afterSemAn {

	void afterSemAn_checkDeclaration(ICompiler_semAn compiler);

}

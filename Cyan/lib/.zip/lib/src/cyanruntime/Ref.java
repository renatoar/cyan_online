package cyanruntime;

public class Ref<T> { 
	public Ref(T elem) { this.elem = elem; }
	public Ref() { }
    public T elem; 
}
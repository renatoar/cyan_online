package cyanruntime;

public class NonExistingJavaClass {
}




